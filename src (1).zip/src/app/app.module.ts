import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule,ErrorHandler } from '@angular/core';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { IndividualModule } from './pages/individual/individual.module';
import { ManagerModule } from './pages/manager/manager.module';
import { MaterialModule } from './shared/material-module';
import { TokenInterceptorService } from './core/services/token-interceptor.service';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'
import { HttpErrorInterceptor } from './core/services/http-error.interceptor.service';
import { LoggingService } from './core/services/logging.service';
import { CacheInterceptorService } from './core/services/cache-interceptor.service';
import { environment } from 'src/environments/environment';
import { GlobalErrorHandler } from './core/services/global-error-handler.service';
import { InitiativeFilterComponent } from './pages/initiative/initiative-filter/initiative-filter.component';
import { InitiativeRequirementComponent } from './pages/initiative/initiative-requirement/initiative-requirement.component';

export function loginThroughAzureAD(adalService: MsAdalAngular6Service) {
  return () => new Promise((resolve) => {
    if (adalService.isAuthenticated) {
      resolve();
    } else {
      adalService.login();
    }
  });
}

@NgModule({
 declarations: [
    AppComponent,
    InitiativeFilterComponent,
    InitiativeRequirementComponent 
  ],
  imports: [
    FormsModule,
    BrowserModule, 
    BrowserAnimationsModule,
    AppRoutingModule,

    MsAdalAngular6Module.forRoot({
      tenant: environment.AD.tenant,
      clientId: environment.AD.clientId,
      redirectUri: environment.AD.redirectURL
    }),

    CoreModule,
    IndividualModule,
    ManagerModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    HttpClientModule,
    MatProgressSpinnerModule
  ],

  providers: [ 
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CacheInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },   
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
     {
     provide: ErrorHandler,
     useClass: GlobalErrorHandler
   }

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
