import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-initiative-filter',
  templateUrl: './initiative-filter.component.html',
  styleUrls: ['./initiative-filter.component.css']
})
export class InitiativeFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
