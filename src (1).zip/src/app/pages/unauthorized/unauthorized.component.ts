import { Component, OnInit } from '@angular/core';
import { AuthGuard } from '../../guards/auth.guard';
@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.css']
})
export class UnauthorizedComponent implements OnInit {

  constructor(private authGuard:AuthGuard) {
    this.authGuard.loader=false;
   }

  ngOnInit() {
  }

}
