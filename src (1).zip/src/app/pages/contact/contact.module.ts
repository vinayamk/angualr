import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactDialogComponent } from './contact-dialog/contact-dialog.component';
import { MaterialModule } from '../../shared/material-module';
@NgModule({
  declarations: [ContactDialogComponent],
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports:[ContactDialogComponent]
})
export class ContactModule { }
