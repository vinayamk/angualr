export interface JobRoleGrade {
 id: number;
  value: string;
}
