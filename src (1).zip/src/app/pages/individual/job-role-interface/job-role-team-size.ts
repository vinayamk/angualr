export interface JobRoleTeamSize {
id: number;
  value: string;
}
