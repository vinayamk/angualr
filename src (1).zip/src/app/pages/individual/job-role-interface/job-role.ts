export interface JobRole {
    jobrole: string;
  specialityField: string;
  description: string;
  yearsOfExperience: number;
  FinalyearsOfExperience: number;
  projectsManaged: number;
  projectTeamSize: number;
}
