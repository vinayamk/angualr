import { SingleSkillSubmitInterface } from './single-skill-submit.interface';

export interface FinalSkillSubmitInterface {
    employeeId: string;
    skills: SingleSkillSubmitInterface[];
}