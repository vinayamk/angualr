export interface SkillAndRatingInterface {
    firstCategory: string;
    secondCategory: string;
    thirdCategory: string;
    fourthCategory: string;
    fifthCategory: string;
    skillId: number;
    skillClassification: string;
    initialRating: number;
    finalRating: number;
    isAlreadySelected: boolean;
}