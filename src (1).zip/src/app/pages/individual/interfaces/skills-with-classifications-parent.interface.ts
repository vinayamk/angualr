import { AllSkillsWithClassificationInterface } from './all-skills-with-classifications.interface';
import { SelectedSkillsWithClassificationInterface } from './selected-skills-with-classifications.interface';

export interface SkillsWithClassificationsParentInterface {
    allSkillsWithClassifications: AllSkillsWithClassificationInterface;
    selectedSkillsWithClassifications: SelectedSkillsWithClassificationInterface;
}