import { SkillAndRatingInterface } from './skill-and-rating.interface';

export interface SelectedSkillsWithClassificationInterface {
    initialSkills: SkillAndRatingInterface[];
    finalSkills: SkillAndRatingInterface[];
}