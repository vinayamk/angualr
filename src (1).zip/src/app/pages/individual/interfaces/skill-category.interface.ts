export interface SkillCategoryInterface {
  firstCategoryName: string;
  secondCategoryName: string;
  thirdCategoryName: string;
  fourthCategoryName: string;
  fifthCategoryName: string;
}