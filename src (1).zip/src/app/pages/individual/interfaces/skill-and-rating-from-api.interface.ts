export interface SkillAndRatingFromAPIInterface {
    skillLevels:         string[];
    skillId:             number;
    skillClassification: string;
    ratingId:            number;
}