export interface FirstAndSecondCategoryInterface {
    firstCategoryName: string,
    secondCategoryList: Set<string>;
}