export interface SingleSkillSubmitInterface {
    skillId: number;
    ratingId: number;
}