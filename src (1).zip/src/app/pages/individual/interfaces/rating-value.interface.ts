export interface RatingValuesInterface {
    id: number;
    value: string;
}