import { SkillAndRatingInterface } from './skill-and-rating.interface';

export interface PopUpSkillsWithClassificationInterface {
    initialSelectedSkills: SkillAndRatingInterface[];
    finalSelectedSkills: SkillAndRatingInterface[];
}