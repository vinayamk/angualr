import { SkillAndRatingInterface } from './skill-and-rating.interface';

export interface AllSkillsWithClassificationInterface {
    initialSkills: SkillAndRatingInterface[];
    finalSkills: SkillAndRatingInterface[];
    selectedSkills: SkillAndRatingInterface[];
    unSelectedSkills: SkillAndRatingInterface[];
}