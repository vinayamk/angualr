export interface SkillTableFilterInterface {
    firstCategoryFilter: string;
    secondCategoryFilter: string;
    skillClassificationFilter: string;
    searchFilter: string;
}