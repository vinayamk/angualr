import { Component, OnInit,ViewChild,ElementRef,Renderer2} from '@angular/core';

import { IndividualSkillService } from './individual-skill.service';
import { SkillCategoryInterface } from '../interfaces/skill-category.interface';
import { SkillAndRatingInterface } from '../interfaces/skill-and-rating.interface';
import { MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { RatingValuesInterface } from '../interfaces/rating-value.interface';
import { environment } from 'src/environments/environment';
import { FirstAndSecondCategoryInterface } from '../interfaces/first-and-second-category.interface';
import { SingleSkillSubmitInterface } from '../interfaces/single-skill-submit.interface';
import { IndividualSkillDialogComponent } from '../individual-skill-dialog/individual-skill-dialog.component';
import { SkillTableDataSource } from '../models/skill-table-data-source.class';
import { SkillTableFilterInterface } from '../interfaces/skill-table-filter.interface';
import { FinalSkillSubmitInterface } from '../interfaces/final-skill-submit.interface';
import { FormGroup, FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { UserService } from 'src/app/core/services/user.service';
import { SkillProficiencyDialogComponent } from '../skill-proficiency-dialog/skill-proficiency-dialog.component';
import { DataStoreService, SKILL_CLASSIFICATION_VALUES } from 'src/app/core/services/data-store.service';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { Observable } from 'rxjs';
// TODO: Console log error of Http Request -> Put in file or something
@Component({
  selector: 'app-individual-skill',
  templateUrl: './individual-skill.component.html',
  styleUrls: ['./individual-skill.component.css'],
})
export class IndividualSkillComponent implements OnInit {

   @ViewChild('skillTable') skillTable: ElementRef;

  /** Contains the names of the skill level category */
  skillCategoryNames: SkillCategoryInterface;

  /** Data Source for the Skills Table */
  skillDataSource: SkillTableDataSource<SkillAndRatingInterface>;

  /** Holds first category skills mapped to their respective second category skills */
  firstAndSecondCategorySkills: FirstAndSecondCategoryInterface[];
  /** The 'All' option object in the Level 1 filtering */
  allSkillsFirstCategory: FirstAndSecondCategoryInterface = {
    firstCategoryName: 'All',
    secondCategoryList: new Set()
  };

  /** Determine if first category skill is selected or no to toggle show/hide of Level 2 filter */
  isSkillFirstCategorySelected: boolean;
  /** The selected first category skill */
  skillFirstCategorySelection: string;
  /** The second category skills based on the selected first category skill */
  selectedSecondCategorySkills: string[];

  /** Contains the skill classifications */
  skillClassifications: string[];

  /** The columns and the order to be displayed in the Material Table */
  displayedColumns: string[];

  /** The final skills to be submitted to API */
  skillSubmitObject: FinalSkillSubmitInterface;

  /** The rating values to be displayed in the rating bar */
  ratingValuesList: RatingValuesInterface[];

  /** Contains the filter values for each of the filtering parameters */
  skillTableFilter: SkillTableFilterInterface;

  /** Contains the filter string which holds first, second level category and the skill classification */
  totalFilterString: string;

  /** Holds reference of the mySkill Dialog */
  skillDialogRef: MatDialogRef<IndividualSkillDialogComponent>;

  // TODO: Comments
  skillProficiencyDialogRef: MatDialogRef<SkillProficiencyDialogComponent>;

  /** Reference of the table search bar form group */
  searchFieldForm: FormGroup;

  // TODO: Comments
  isComponentLoading: boolean;

  // TODO: Comments
  isTableLoading: boolean;

  // TODO: Comments
  noSkillsMessage: string;

  // TODO: Comments
  isCycleOpen: boolean;

  // TODO: Remove the user service.
  constructor(private individualSkillService: IndividualSkillService,
              private dialog: MatDialog,
              private userService: UserService,
              private dataStoreService: DataStoreService,
              private snackBar: MatSnackBar,
              private authGuard: AuthGuard,
              private renderer: Renderer2, 
              private el: ElementRef) {
    this.authGuard.loader = true;
  }

  ngOnInit() {
    this.noSkillsMessage = environment.SKILLS_LOADING_MESSAGE;

    this.skillDataSource = new SkillTableDataSource();

    this.isSkillFirstCategorySelected = false;
    this.skillFirstCategorySelection = "";

    this.firstAndSecondCategorySkills = [];
    this.selectedSecondCategorySkills = [];

    this.skillClassifications = SKILL_CLASSIFICATION_VALUES;

    this.ratingValuesList = [];

    this.getSkillCategoryNames();
    this.getAllSkillsWithRatingsList();
    this.getRatingValuesList();

    this.skillTableFilter = {
      firstCategoryFilter: "",
      secondCategoryFilter: "",
      skillClassificationFilter: "",
      searchFilter: ""
    };
    this.totalFilterString = "";

    this.displayedColumns = environment.DISPLAY_COLUMNS.Survey_A;

    this.skillSubmitObject = {
      employeeId: '',
      skills: []
    }

    // TODO: Comments
    this.dataStoreService.GIDBehaviorSubject
      .subscribe((data: string) => {
        this.skillSubmitObject.employeeId = data;
      });

    // TODO: Comments
    this.dataStoreService.cycleBehaviorSubject
      .subscribe((data: boolean) => {
        this.isCycleOpen = data;
      })

    this.searchFieldForm = new FormGroup({
      'searchInput': new FormControl('')
    });

    // Search Bar, control the filtering.
    this.searchFieldForm.get('searchInput')
      .valueChanges
      .pipe(
        debounceTime(1000),
        distinctUntilChanged()
      )
      .subscribe((searchValue: string) => {
        this.skillTableFilter.searchFilter = searchValue;
        this.applyFilter();
      });
  }

  // TODO: Comments
  canDeactivate(): Observable<boolean> | boolean {
    let userOption: boolean;
    if (this.skillSubmitObject.skills.length !== 0) {
      userOption = window.confirm(environment.MOVE_FROM_SURVEY_A_TO_B_MESSAGE);
      if(!userOption) {
        return false;
      }
      else if(userOption){
        this.resetSkills();
      }
    }
    return true;
  }

  // TODO: Comments
  /**
   * Get the skill Level Category Names
   */
  getSkillCategoryNames() {
    if(this.dataStoreService.checkIfEmptySkillCategoryNames())  {
      this.individualSkillService.getSkillLevelCategories()
        .subscribe((data: SkillCategoryInterface) => {
          this.dataStoreService.skillCategoryNames = data;
          this.skillCategoryNames = this.dataStoreService.skillCategoryNames;
  
          if(this.dataStoreService.checkIfAllSkillsComponentDataLoaded()) {
            this.authGuard.loader = false;
          }
      }, (error) => {
        console.log(error);
      });
    }
    else {
      this.skillCategoryNames = this.dataStoreService.skillCategoryNames;
    }
  }

  // TODO: Comments
  /**
   * Get all skills with their ratings
   */
  getAllSkillsWithRatingsList() {
    if(this.dataStoreService.checkIfEmptySkillsWithClassifications()) {
      this.individualSkillService.getAllSkillsWithRatings()
        .subscribe((data: SkillAndRatingInterface[]) => {
          this.individualSkillService.seperateDataBasedOnSelection(data);

          this.skillDataSource.data = this.dataStoreService.allSkillsWithClassification.finalSkills;

          this.dataStoreService.firstAndSecondCategorySkills = this.populateFirstAndSecondCategorySkills(
            this.dataStoreService.allSkillsWithClassification.initialSkills);
          this.firstAndSecondCategorySkills = this.dataStoreService.firstAndSecondCategorySkills;

          if(this.dataStoreService.checkIfAllSkillsComponentDataLoaded()) {
            this.authGuard.loader = false;
          }
        }, (error) => {
          console.log(error);
        });
    }
    else {
      // Fake loading for performance
      setTimeout(() => {
        this.skillDataSource.data = this.dataStoreService.allSkillsWithClassification.finalSkills;

        this.firstAndSecondCategorySkills = this.dataStoreService.firstAndSecondCategorySkills;

        this.authGuard.loader = false;
      }, 1000);

    }
  }

  /**
   * Get rating id and values
   */
  getRatingValuesList() {
    if(this.dataStoreService.checkIfEmptyRatingValuesList()) {
      this.individualSkillService.getRatingValues()
        .subscribe((data: RatingValuesInterface[]) => {
          let ratingValuesList = [];
          ratingValuesList = data;
          ratingValuesList.unshift({
            id: 0,
            value: 'N/A'
          });

          this.dataStoreService.ratingValuesList = ratingValuesList;

          this.ratingValuesList = this.dataStoreService.ratingValuesList;

          if(this.dataStoreService.checkIfAllSkillsComponentDataLoaded()) {
            this.authGuard.loader = false;
          }
        }, (error) => {
          console.log(error);
        })
    }
    
    else {
      this.ratingValuesList = this.dataStoreService.ratingValuesList;      
    }
  }

  /**
   * Populates the first and second category skills for Level 1 and Level 2 filtering
   * @param skillsData All skills with ratings recieved from API
   */
  populateFirstAndSecondCategorySkills(skillsData: SkillAndRatingInterface[]): FirstAndSecondCategoryInterface[] {
      let firstAndSecondCategorySkills = [];
      this.individualSkillService.prepareFirstAndSecondCategorySkills(skillsData)
        .subscribe((data: FirstAndSecondCategoryInterface) => {
          firstAndSecondCategorySkills.push(data);
        }, (error) => {
          console.log(error);
        }, () => {
          // Add the 'All' option at the first position
          firstAndSecondCategorySkills.unshift(this.allSkillsFirstCategory);
        });
      this.individualSkillService.sortSkillCategories(firstAndSecondCategorySkills)
      return firstAndSecondCategorySkills;
  }

  /**
   * Filters the data table based on the first level skill category selection.
   * @param skillCategorySelected The first category skill selected.
   */
  onSkillFirstCategorySelection(skillCategorySelected: FirstAndSecondCategoryInterface) {
    // If 'All' selected, remove all level categoryfiltering.
    if(skillCategorySelected.firstCategoryName.toLowerCase() === 'all') {
      this.isSkillFirstCategorySelected = false;

      this.skillTableFilter.firstCategoryFilter = "";
      this.skillTableFilter.secondCategoryFilter = "";

      this.selectedSecondCategorySkills = [];
    }
    else {
      this.isSkillFirstCategorySelected = true;

      this.skillTableFilter.firstCategoryFilter = skillCategorySelected.firstCategoryName;
      this.skillTableFilter.secondCategoryFilter = "";

      this.selectedSecondCategorySkills = Array.from(skillCategorySelected.secondCategoryList);
    }
    this.applyFilter();
  }

  /**
   * Filters the data table based on the first level and second level skill category selection.
   * @param skillCategorySelected The second category skill selected.
   */
  onSkillSecondCategorySelection(skillCategorySelected: string) {
    // If 'All' selected, remove second category filtering.
    if(skillCategorySelected.toLowerCase() === 'all') {
      this.skillTableFilter.secondCategoryFilter = "";
    }

    else {
      this.skillTableFilter.secondCategoryFilter = skillCategorySelected;
    }
    this.applyFilter();
  }

  /**
   * Filters the data table based on the skill classification selected.
   * @param skillClassificationSelected The skill classification selected.
   */
  onSkillClassificationSelection(skillClassificationSelected: string) {
    if(skillClassificationSelected.toLowerCase() === 'all')  {
      this.skillTableFilter.skillClassificationFilter = "";
    }

    else {
      this.skillTableFilter.skillClassificationFilter = skillClassificationSelected;
    }
    this.applyFilter();
  }

  /**
   * Gets the search bar filter.
   * @param filterValue The value typed into the search bar..
   */
  getSearchFilterString(filterValue: string) {
    this.skillTableFilter.searchFilter = filterValue;
    this.applyFilter();
  }

  /**
   * Takes the SkillTableFilterInterface and converts it to string format for filtering returning the same
   */
  prepareTotalFilterStringBasedOnFilterObject(): string {
    let filterString = "";

    filterString = this.skillTableFilter.firstCategoryFilter + environment.matTableColumnSeperator + 
      this.skillTableFilter.secondCategoryFilter + environment.matTableColumnSeperator +
      this.skillTableFilter.skillClassificationFilter + environment.matTableColumnSeperator + 
      this.skillTableFilter.searchFilter;
    
    return filterString;
  }

  /**
   * Apply filter on the Table Data Source
   */
  applyFilter() {
    this.authGuard.loader = true;
   
    // Scroll to container top - Only if table not empty
    if(this.skillDataSource.filteredData.length !== 0) {
      this.skillTable.nativeElement.scrollTop = 0;
    }
    
    this.totalFilterString = this.prepareTotalFilterStringBasedOnFilterObject();

    setTimeout(() => {
      this.authGuard.loader = false;

      this.skillDataSource.filter = this.totalFilterString;

      if(this.skillDataSource.filteredData.length === 0) {
        this.noSkillsMessage = environment.NO_SKILLS_AFTER_FILTER_MESSAGE;
      }
  
      else {
        this.noSkillsMessage = environment.SKILLS_LOADING_MESSAGE;
      }
    }, 1000);
  }

  // TODO: Remove the console.log
  /**
   * Event called on select of the rate. 
   * @param skill The skill object related to the row where the event occured.
   * @param event The selected rating.
   */
  onRateChanged(skill: SkillAndRatingInterface, rating: number) {
    skill.finalRating = rating;
    this.addSkillToFinalObject(skill);
    console.log(this.skillSubmitObject);
  }

  /**
   * Adds the skill object to the final skill object.
   * @param skill Skill object.
   */
  addSkillToFinalObject(skill: SkillAndRatingInterface) {
    // Remove the skill from skill object if initial and final rating are the same
    if(skill.finalRating === skill.initialRating)  {
      this.skillSubmitObject.skills = this.skillSubmitObject.skills.filter((skillInSubmitObject) => {
        if(skillInSubmitObject.skillId !== skill.skillId)  {
          return skillInSubmitObject;
        }
      })
      return;
    }

    let isSkillInFinalObject: boolean;
    let skillObjectForSubmit: SingleSkillSubmitInterface = {
      skillId: skill.skillId,
      ratingId: skill.finalRating
    };

    // Update the rating of the skill if skill is already present in the final object
    this.skillSubmitObject.skills.filter((skillInSubmitObject) => {
      if(skillInSubmitObject.skillId === skill.skillId)  {
        skillInSubmitObject.ratingId = skill.finalRating;
        isSkillInFinalObject = true;
      }
    })

    // Add the skill into the final object if not present initially
    if(!isSkillInFinalObject) {
      this.skillSubmitObject.skills.push(skillObjectForSubmit);
    }
  }

  // TODO: Get status and progress from API and remove console.log
  /**
   * Submit the final skills object to API
   */
  submitSkills() {
    this.authGuard.loader = true;

    // Submit the final object to API if not empty
    if(this.skillSubmitObject.skills.length !== 0)  {
      console.log("Sending skills");
      this.individualSkillService.submitSkillToAPI(this.skillSubmitObject)
        .subscribe(data => {
          console.log(data);

          // From now on, the rating will be the one saved.
          this.dataStoreService.allSkillsWithClassification.finalSkills.forEach((skill) => {
            skill.initialRating = skill.finalRating;
          });

          // Update the data to the final skills after submit
          this.individualSkillService.seperateDataBasedOnSelection(
            this.dataStoreService.allSkillsWithClassification.finalSkills
          );

          setTimeout(() => {
            this.authGuard.loader = false;

            this.skillDataSource.data = this.dataStoreService.allSkillsWithClassification.finalSkills;

            this.snackBar.open('Skills Saved', 'Done', {
              duration: 2000,
              verticalPosition: 'top'
            });
          }, 1000);

          // Clear the skill submit object list.
          this.skillSubmitObject.skills = [];
        }, error => console.log(error));
    }
  }

  /**
   * Reset the skills data
   */
  resetSkills() {
    // Reset the final object if not empty
    if(this.skillSubmitObject.skills.length !== 0)  {
      this.authGuard.loader = true;

      // Reset data to initial skills
      this.individualSkillService.seperateDataBasedOnSelection(
        this.dataStoreService.allSkillsWithClassification.initialSkills
      );

      // Clear the skill submit object list.
      this.skillSubmitObject.skills = [];

      setTimeout(() => {
        this.authGuard.loader = false;

        this.skillDataSource.data = this.dataStoreService.allSkillsWithClassification.finalSkills;

        this.snackBar.open('Skills Cancelled', 'Done', {
          duration: 2000,
          verticalPosition: 'top'
        });
      }, 1000);
    }
  }

  // TODO: Table header names and rating values list. Get from global service.
  /**
   * Opens the Selected Skills Pop-up
   */
  openSelectedSkillDialog() {
    this.skillDialogRef = this.dialog.open(IndividualSkillDialogComponent);

    this.skillDialogRef.afterClosed()
      .subscribe(data => {
        if(data) {
          this.authGuard.loader = true;

          setTimeout(() => {
            this.authGuard.loader = false

            this.skillDataSource.data = this.dataStoreService.allSkillsWithClassification.finalSkills;
          }, 1000);
        } 
      });
  }

  // TODO: Comments
  openSkillProficiencyImagePopup() {
    this.skillProficiencyDialogRef = this.dialog.open(SkillProficiencyDialogComponent);
  }
}