import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { SkillCategoryInterface } from '../interfaces/skill-category.interface';
import { SkillAndRatingInterface } from '../interfaces/skill-and-rating.interface';
import { RatingValuesInterface } from '../interfaces/rating-value.interface';
import { concatAll, groupBy, mergeMap, reduce, map, combineAll,tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { SkillAndRatingFromAPIInterface } from '../interfaces/skill-and-rating-from-api.interface';
import { AllSkillsWithClassificationInterface } from '../interfaces/all-skills-with-classifications.interface';
import { SelectedSkillsWithClassificationInterface } from '../interfaces/selected-skills-with-classifications.interface';
import { FinalSkillSubmitInterface } from '../interfaces/final-skill-submit.interface';
import { DataStoreService } from 'src/app/core/services/data-store.service';
import { SkillsWithClassificationsParentInterface } from '../interfaces/skills-with-classifications-parent.interface';
import { FirstAndSecondCategoryInterface } from '../interfaces/first-and-second-category.interface';

@Injectable()
export class IndividualSkillService {
  constructor(private http: HttpClient,
              private dataStoreService: DataStoreService,private router:Router )  {}

  // TODO: Need change in API. Data coming in Array. Need in interface type
  /**
   * Gets the Skill Level header names.
   * Data is manipulated to resemble the SkillCategoryInterface
   */
  getSkillLevelCategories() {
    return this.http.get<string[]>(
      environment.API.baseAPIURL + environment.API.SurveyA_Skills_API_URLs.GETRequestURLs.SkillCategories
    ).pipe(
      map((skillCategory: string[]): SkillCategoryInterface => {
        return {
          firstCategoryName: skillCategory[0],
          secondCategoryName: skillCategory[1],
          thirdCategoryName: skillCategory[2],
          fourthCategoryName: skillCategory[3],
          fifthCategoryName: skillCategory[4]
        };
      })
    );
  }

  /**
   * Gets all the skills with their ratings.
   * Data is manipulated to resemble the SkillAndRatingInterface
   * 
   * Extra Note:
   * 1. concatAll()  --> Breaks down the Observable Array into individual Observables.
   * 2. map()        --> Map each Observable to the SkillAndRatingInterface.
   * 3. combineAll() --> Collect all Observable into single Observable of SkillAndRatingInterface Array.
   */
  getAllSkillsWithRatings() {
    return this.http.get<SkillAndRatingFromAPIInterface[]>(
      environment.API.baseAPIURL + environment.API.SurveyA_Skills_API_URLs.GETRequestURLs.SkillsWithRating
    ).pipe(
      tap((data)=>{
      
         //this.router.navigate(['/unauthorized']);
          console.log(data);
      }),
      concatAll(),
      map((data: SkillAndRatingFromAPIInterface): Observable<SkillAndRatingInterface> => {
        let length = data.skillLevels.length;
         console.log(data.skillLevels.length)
          if(data.skillLevels.length==9){
            console.log((data.skillLevels.length))
          }

        return of({
          firstCategory: data.skillLevels[length - 5],
          secondCategory: data.skillLevels[length - 4],
          thirdCategory: data.skillLevels[length - 3],
          fourthCategory: data.skillLevels[length - 2],
          fifthCategory: data.skillLevels[length - 1],
          skillId: data.skillId,
          skillClassification: data.skillClassification,
          initialRating: data.ratingId,
          finalRating: data.ratingId,
          isAlreadySelected: data.ratingId !== 0
        })
      }),
      combineAll()
    );
  }

  // TODO: Update Comments
  /**
   * Seperates all the skills into the format AllSkillsWithClassificationInterface.
   * Seperates all the selected skills into the format SelectedSkillsWithClassificationInterface.
   * 
   * @param data All skills in SkillAndRatingInterface Array.
   * 
   * @param selectedData The selected skills. Optional. If not sent, will take empty Array.
   *        Purpose: Used to update the selected skills from Pop-up.
   * 
   * More comments within the method.
   */
  seperateDataBasedOnSelection(data: SkillAndRatingInterface[],
    selectedData: SkillAndRatingInterface[] = []) {

    this.dataStoreService.allSkillsWithClassification = {
      initialSkills: data,
      finalSkills: [],
      selectedSkills: selectedData,
      unSelectedSkills: []
    }

    this.dataStoreService.selectedSkillsWithClassification = {
      initialSkills: [],
      finalSkills: []
    }
    
    // The selected skills as passed to the method are updated to the initial Skills Array.
    // Then the selected skills are emptied to trigger a fresh seperation of skills.
    for(const selectedSkill of selectedData) {
      if(selectedSkill.initialRating === 0) {
        selectedSkill.isAlreadySelected = false;
      }

      for(const skill of data) {
        if(selectedSkill.skillId === skill.skillId) {
          this.dataStoreService.allSkillsWithClassification.initialSkills[
            this.dataStoreService.allSkillsWithClassification.initialSkills.indexOf(skill)] = selectedSkill;
        }
      }
    }
    selectedData = [];
    this.dataStoreService.allSkillsWithClassification.selectedSkills = [];

    for (const iterator of data) {
      // This condition takes in effect when we submit the skills by modifying them.
      //#region isAlreadySelectedChange
      if(iterator.initialRating !== 0) {
        iterator.isAlreadySelected = true;
      }

      else if(iterator.initialRating === 0) {
        iterator.isAlreadySelected = false;
      }
      //#endregion

      if(iterator.isAlreadySelected) {
        this.dataStoreService.allSkillsWithClassification.selectedSkills.push(iterator);
      }
      else {
        this.dataStoreService.allSkillsWithClassification.unSelectedSkills.push(iterator);
      }
    }

    this.sortSkillsWithRatings(this.dataStoreService.allSkillsWithClassification.selectedSkills);
    this.sortSkillsWithRatings(this.dataStoreService.allSkillsWithClassification.unSelectedSkills);

    // The data source for the Pop-up table.
    this.dataStoreService.selectedSkillsWithClassification.initialSkills = 
    this.dataStoreService.allSkillsWithClassification.selectedSkills;
    
    // Create a deep copy of initial Skills and use it as Data Source for the Pop-up table
    // so that we can reset data to initial skills.
    this.dataStoreService.selectedSkillsWithClassification.finalSkills = JSON.parse(
      JSON.stringify(this.dataStoreService.selectedSkillsWithClassification.initialSkills)
    );

    // Total list of all skills - a combination of ordered selected and unselected skills respectively.
    this.dataStoreService.allSkillsWithClassification.initialSkills = [
      ...this.dataStoreService.allSkillsWithClassification.selectedSkills,
      ...this.dataStoreService.allSkillsWithClassification.unSelectedSkills
    ];

    // Create a deep copy of initial Skills and use it as Data Source for the Main Skill table
    // so that we can reset data to initial skills.
    this.dataStoreService.allSkillsWithClassification.finalSkills = JSON.parse(
      JSON.stringify(this.dataStoreService.allSkillsWithClassification.initialSkills)
    );
  }

  /**
   * Sorts the SkillAndRatingInterface Array passed in as the input.
   * @param data SkillAndRatingInterface Array to be sorted
   */
  sortSkillsWithRatings(data: SkillAndRatingInterface[]) {
    data.sort((firstElement, secondElement) => {
      return firstElement.skillId - secondElement.skillId;
    });
  }

  /**
   * Gets the rating lookup.
   * Data already coming in the RatingValuesInterface format.
   */
  getRatingValues() {
    return this.http.get<RatingValuesInterface[]>(
      environment.API.baseAPIURL + environment.API.SurveyA_Skills_API_URLs.GETRequestURLs.RatingValues
    );
  }

  // TODO: Need more understanding.
  /**
   * Prepares the first and second category skills for Level 1 and Level 2 filtering
   * @param data All skills with ratings data recieved from API
   * 
   * Extra Note:
   * 1. concatAll() --> Breaks down the Observable Array into individual Observables.
   * 2. groupBy()   --> Group each Observable based on the first and second category.
   * 3. mergeMap()  --> Merge all the Grouped Observables into single Observable Group.
   * 4. reduce()    --> Combine all the Observables into single Observable.
   * 5. map()       --> Manipulate the Observable to get the data in FirstAndSecondCategoryInterface. 
   */
  prepareFirstAndSecondCategorySkills(data: SkillAndRatingInterface[]) {
    return of(data)
      .pipe(
        concatAll(),
        groupBy(skill => skill.firstCategory, skill => skill.secondCategory),
        mergeMap(group$ =>
          group$.pipe(
            reduce(
              (acc, cur) => [...acc, cur], [`${group$.key}`])
              )
        ),
        map(arr => ({ firstCategoryName: arr[0], secondCategoryList: new Set(arr.slice(1)) }))
      );
  }

  /**
   * Sorts the FirstAndSecondCategoryInterface Array passed in as the input.
   * @param data FirstAndSecondCategoryInterface Array to be sorted
   */
  sortSkillCategories(data: FirstAndSecondCategoryInterface[]) {
    data.sort((firstElement, secondElement) => {
      let firstElementCategoryName = firstElement.firstCategoryName.toUpperCase();
      let secondElementCategoryName = secondElement.firstCategoryName.toUpperCase();
      if (firstElementCategoryName < secondElementCategoryName) {
        return -1;
      }
      if (firstElementCategoryName > secondElementCategoryName) {
        return 1;
      }
      return 0;
    });
  }

  // TODO: Try the generic post method
  /**
   * Submit the final skill object to API. 
   * @param finalSkillObject The data in the format of FinalSkillSubmitInterface
   */
  submitSkillToAPI(finalSkillObject: FinalSkillSubmitInterface) {
    return this.http.post(
      environment.API.baseAPIURL + environment.API.SurveyA_Skills_API_URLs.POSTRequestURLs.SubmitSkills,
      finalSkillObject
    );
  }
}
