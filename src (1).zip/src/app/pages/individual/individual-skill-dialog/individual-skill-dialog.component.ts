import { OnInit, Component } from '@angular/core';
import { IndividualSkillService } from '../individual-skill/individual-skill.service';
import { MatDialogRef, MatSnackBar } from '@angular/material';
import { SkillAndRatingInterface } from '../interfaces/skill-and-rating.interface';
import { SkillCategoryInterface } from '../interfaces/skill-category.interface';
import { RatingValuesInterface } from '../interfaces/rating-value.interface';
import { SkillTableDataSource } from '../models/skill-table-data-source.class';
import { SingleSkillSubmitInterface } from '../interfaces/single-skill-submit.interface';
import { FinalSkillSubmitInterface } from '../interfaces/final-skill-submit.interface';
import { environment } from 'src/environments/environment';
import { UserService } from 'src/app/core/services/user.service';
import { DataStoreService } from 'src/app/core/services/data-store.service';
import { AuthGuard } from 'src/app/guards/auth.guard';

// TODO: Console.log error to file
@Component({
  selector: 'app-individual-skill-dialog',
  templateUrl: './individual-skill-dialog.component.html',
  styleUrls: ['./individual-skill-dialog.component.css']
})
export class IndividualSkillDialogComponent implements OnInit {
  /** Data Source for the Selected Skills Table */
  skillDataSource: SkillTableDataSource<SkillAndRatingInterface>;

  /** Contains the names of the skill level category */
  skillCategoryNames: SkillCategoryInterface;

  /** The rating values to be displayed in the rating bar */
  ratingValuesList: RatingValuesInterface[];

  /** The columns and the order to be displayed in the Material Table */
  displayedColumns: string[];

  /** The final skills to be submitted to API */
  skillSubmitObject: FinalSkillSubmitInterface;

  // TODO: Comments
  isSubmittedAtleastOnce: boolean;

  // TODO: Comments
  isCycleOpen: boolean;
  
  // TODO: Remove the user service.
  constructor(private individualSkillService: IndividualSkillService,
              private dialogRef: MatDialogRef<IndividualSkillDialogComponent>,
              private userService: UserService,
              private dataSourceService: DataStoreService,
              private snackBar: MatSnackBar,
              private authGuard: AuthGuard) {}

  ngOnInit() {
    this.isSubmittedAtleastOnce = false;

    this.skillDataSource = new SkillTableDataSource();
    this.skillDataSource.data = this.dataSourceService.selectedSkillsWithClassification.finalSkills;

    this.skillCategoryNames = this.dataSourceService.skillCategoryNames;
    this.ratingValuesList = this.dataSourceService.ratingValuesList;
    this.displayedColumns = environment.DISPLAY_COLUMNS.Survey_A;

    this.skillSubmitObject = {
      employeeId: '',
      skills: []
    }

    // TODO: Change from Observable to string
    this.dataSourceService.GIDBehaviorSubject
      .subscribe((data: string) => {
        this.skillSubmitObject.employeeId = data;
      });

    // TODO: Comments
    this.dataSourceService.cycleBehaviorSubject
      .subscribe((data: boolean) => {
        this.isCycleOpen = data;
      })

    // TODO: Do we need this?
    // Close dialog on clicking background.
    // This event is captured to pass data to calling component.
    this.dialogRef.backdropClick()
      .subscribe(next => this.closeDialog());
  }

  /**
   * Event called on select of the rate. 
   * @param skill The skill object related to the row where the event occured.
   * @param event The selected rating.
   */
  onRateChanged(skill: SkillAndRatingInterface, rating: number) {
    skill.finalRating = rating;
    this.addSkillToFinalObject(skill);
    console.log(this.skillSubmitObject);
  }

  /**
   * Adds the skill object to the final skill object.
   * @param skill Skill object.
   */
  addSkillToFinalObject(skill: SkillAndRatingInterface) {
    // Remove the skill from skill object if initial and final rating are the same
    if(skill.finalRating === skill.initialRating)  {
      this.skillSubmitObject.skills = this.skillSubmitObject.skills.filter((skillInSubmitObject) => {
        if(skillInSubmitObject.skillId !== skill.skillId)  {
          return skillInSubmitObject;
        }
      })
      return;
    }

    let isSkillInFinalObject: boolean;
    let skillObjectForSubmit: SingleSkillSubmitInterface = {
      skillId: skill.skillId,
      ratingId: skill.finalRating
    };

    // Update the rating of the skill if skill is already present in the final object
    this.skillSubmitObject.skills.filter((skillInSubmitObject) => {
      if(skillInSubmitObject.skillId === skill.skillId)  {
        skillInSubmitObject.ratingId = skill.finalRating;
        isSkillInFinalObject = true;
      }
    })

    // Add the skill into the final object if not present initially
    if(!isSkillInFinalObject) {
      this.skillSubmitObject.skills.push(skillObjectForSubmit);
    }
  }

  // TODO: Get status and progress and remove console.logs
  /**
   * Submit the final skills object to API
   */
  submitSkills() {
    // Submit the final object to API if not empty
    if(this.skillSubmitObject.skills.length !== 0)  {
      console.log("Sending skills");
      this.individualSkillService.submitSkillToAPI(this.skillSubmitObject)
        .subscribe(data => {
          this.isSubmittedAtleastOnce = true;

          console.log(data);

          // From now on, the rating will be the one saved.
          this.dataSourceService.selectedSkillsWithClassification.finalSkills.forEach((skill) => {
            skill.initialRating = skill.finalRating;
          });

          // Update the data to the final skills after submit
          this.individualSkillService.seperateDataBasedOnSelection(
            this.dataSourceService.allSkillsWithClassification.finalSkills,
            this.dataSourceService.selectedSkillsWithClassification.finalSkills
          );

          this.skillDataSource.data = this.dataSourceService.selectedSkillsWithClassification.finalSkills;
    
          this.snackBar.open('Skills Saved', 'Done', {
            duration: 2000,
            verticalPosition: 'top'
          });

          // Clear the skill submit object list.
          this.skillSubmitObject.skills = [];
        }, error => console.log(error));
    }
  }

  /**
   * Reset the selected skills data
   */
  resetSkills() {
    // Reset the final object if not empty
    if(this.skillSubmitObject.skills.length !== 0)  {
      // Reset data to initial skills
      this.dataSourceService.selectedSkillsWithClassification.finalSkills = JSON.parse(
        JSON.stringify(this.dataSourceService.selectedSkillsWithClassification.initialSkills)
      );

      this.skillDataSource.data = this.dataSourceService.selectedSkillsWithClassification.finalSkills;

      this.snackBar.open('Skills Cancelled', 'Done', {
        duration: 2000,
        verticalPosition: 'top'
      });

      this.skillSubmitObject.skills = [];
    }  
  }

  /**
   * Closes the Pop-up.
   */
  closeDialog() {
    this.dialogRef.close(this.isSubmittedAtleastOnce);
  }
}