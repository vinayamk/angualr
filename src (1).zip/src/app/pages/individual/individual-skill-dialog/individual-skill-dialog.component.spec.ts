import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualSkillDialogComponent } from './individual-skill-dialog.component';

describe('IndividualSkillDialogComponent', () => {
  let component: IndividualSkillDialogComponent;
  let fixture: ComponentFixture<IndividualSkillDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualSkillDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualSkillDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
