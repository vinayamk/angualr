import { Component, OnInit } from '@angular/core';
import { JobRole } from '../job-role-interface/job-role';
import { JobRoleGrade } from '../job-role-interface/job-role-grade';
import { JobRoleTeamSize } from '../job-role-interface/job-role-team-size';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { IndividualJobRoleService } from '../individual-job-role/individual-job-role.service';
import { UserService } from 'src/app/core/services/user.service';
import { AuthGuard } from '../../../guards/auth.guard';


export interface InitialMasterObject {
  experienceId: number;
  jobLevels: any[];
  jobRoleId: number;
  numberOfProjects: number;
  peakTeamSizeId: number;

}


export interface ViewModelJobRole {
  experienceId: number;
  FinalexperienceId: number;
  JobRolename: string;
  SpecalityField: string;
  JobRoleId: number;
  numberOfProjects: number;
  FinalnumberOfProjects: number;
  peakTeamSizeId: number;
  FinalpeakTeamSizeId: number;
  description: string;

}

export interface JobRoleV {
  jobRoleId: number;
  experienceId: number;
  peakTeamSizeId: number;
  numberofProjects: number;
}
export interface JobRoleSubmit {
  employeeId: string;
  jobs: JobRoleV[];
}

@Component({
  selector: 'app-individual-job-role-dialog',
  templateUrl: './individual-job-role-dialog.component.html',
  styleUrls: ['./individual-job-role-dialog.component.css']
})
export class IndividualJobRoleDialogComponent implements OnInit {

  ProjectManagementTableColumns: any[] = ['No', "SpecalityField", "experienceId"];
  TechnicalTableColumns: any[] = ["No", "JobRolename", "SpecalityField", "experienceId"];
  TechnicalTableData: any[];
  ProjectManagementTableData: any[];
  jobgradeList: any[];
  jobPMTeamSizeList: any[];
  ViewModelJobRole: ViewModelJobRole;
  InitilaMasterJobRoleList: InitialMasterObject[];
  MasterTechnicalJobRoleList: ViewModelJobRole[];
  MasterPMjobRoleList: ViewModelJobRole[];
  MasterPMViewObject: ViewModelJobRole;
  MasterTSViewObject: ViewModelJobRole;
  DataDownload: boolean;
  loader: boolean;
  isJobRoelTech: boolean;
  isJobRoelPM: boolean;

  
  constructor(private authGuard: AuthGuard,private IndividualJobRoleService: IndividualJobRoleService, private userService: UserService, private dialogRef: MatDialogRef<IndividualJobRoleDialogComponent>) {

  }
 
  ngOnInit() {

    this.isJobRoelTech = false;
    this.isJobRoelPM = false;

    this.loader = true;
    this.MasterPMViewObject = {
      experienceId: 0,
      FinalexperienceId: 0,
      JobRolename: "",
      SpecalityField: "",
      JobRoleId: 0,
      numberOfProjects: 0,
      FinalnumberOfProjects: 0,
      peakTeamSizeId: 0,
      FinalpeakTeamSizeId: 0,
      description: ""
    }

    this.MasterTSViewObject = {
      experienceId: 0,
      FinalexperienceId: 0,
      JobRolename: "",
      SpecalityField: "",
      JobRoleId: 0,
      numberOfProjects: 0,
      FinalnumberOfProjects: 0,
      peakTeamSizeId: 0,
      FinalpeakTeamSizeId: 0,
      description: ""
    }
    this.DataDownload = false;
    //get peak project team size list
    this.getProjectPeakTeamSizeList();

    //get jobrole grade list
    this.getJobRoleGradeList();
  }

  // Master data logic
  getJobRoleMasterMainObject(MainList) {
    this.InitilaMasterJobRoleList = MainList as InitialMasterObject[];
    this.MasterTechnicalJobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] != "Project Management" && t.experienceId != 0).map(obj => this.PrepareListObjects(obj)).sort(function (a, b) { return b.experienceId - a.experienceId });
    this.MasterPMjobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] != "Total # of PJs managed" && t.jobLevels[1] != "Peak Team Size" && t.experienceId != 0).map(obj => this.PrepareListObjects(obj));
    this.MasterPMViewObject = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] == "Total # of PJs managed" ).map(obj => this.PrepareListObjects(obj))[0];
    this.MasterTSViewObject = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] == "Peak Team Size").map(obj => this.PrepareListObjects(obj))[0];
    this.TechnicalTableData = this.MasterTechnicalJobRoleList;
    this.ProjectManagementTableData = this.MasterPMjobRoleList;
    this.DataDownload = true;

    if (this.MasterTechnicalJobRoleList.length == 0) this.isJobRoelTech = true; else this.isJobRoelTech = false;
    if (this.MasterPMjobRoleList.length == 0) this.isJobRoelPM = true; else this.isJobRoelPM = false;
  }

  PrepareListObjects(obj) {

    this.ViewModelJobRole = {
      experienceId: 0,
      FinalexperienceId: 0,
      JobRolename: "",
      SpecalityField: "",
      JobRoleId: 0,
      numberOfProjects: 0,
      FinalnumberOfProjects: 0,
      peakTeamSizeId: 0,
      FinalpeakTeamSizeId: 0,
      description: ""
    };
    this.ViewModelJobRole.experienceId = obj.experienceId;
    this.ViewModelJobRole.FinalexperienceId = obj.experienceId;
    this.ViewModelJobRole.JobRolename = obj.jobLevels[0];
    this.ViewModelJobRole.SpecalityField = obj.jobLevels[1];
    this.ViewModelJobRole.numberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.FinalnumberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.FinalnumberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.peakTeamSizeId = obj.peakTeamSizeId;
    this.ViewModelJobRole.FinalpeakTeamSizeId = obj.peakTeamSizeId;
    this.ViewModelJobRole.JobRoleId = obj.jobRoleId;
    this.ViewModelJobRole.description = obj.description;

    return this.ViewModelJobRole
  }

  //get Project peak team size List

  getProjectPeakTeamSizeList() {

    this.IndividualJobRoleService.getJobRoleTeamSize()
      .subscribe(data => {
        this.jobPMTeamSizeList = data as JobRoleTeamSize[];
        //console.log(this.jobPMTeamSizeList)
      }, error => console.log(error));

  }

  //get Project peak team size List

  getJobRoleGradeList() {

    this.IndividualJobRoleService.getJobRoleGrades()
      .subscribe(data => {
        this.jobgradeList = data as JobRoleGrade[];

        // TODO: Refine this
        this.jobgradeList.unshift({
          id: 0,
          value: 'N/A'
        });

        this.getJobRoleMasterList();

      },
        error => console.log(error));

  }

  // Get JobRole Master List

  getJobRoleMasterList() {

    this.IndividualJobRoleService.getJobRoleList()
      .subscribe(data => {
        //console.log("jobrole", data);
        this.getJobRoleMasterMainObject(data);
        this.loader = false;
      },
        error => console.log(error));

  }

  closeDialog() {
    this.dialogRef.close();
  }
}
