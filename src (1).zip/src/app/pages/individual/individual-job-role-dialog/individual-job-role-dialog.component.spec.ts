import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualJobRoleDialogComponent } from './individual-job-role-dialog.component';

describe('IndividualJobRoleDialogComponent', () => {
  let component: IndividualJobRoleDialogComponent;
  let fixture: ComponentFixture<IndividualJobRoleDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualJobRoleDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualJobRoleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
