import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { InitiativeComponent } from './initiative.component';
import { InitiativeRequirementComponent } from './initiative-requirement/initiative-requirement.component';
import { InitiativeFilterComponent } from './initiative-filter/initiative-filter.component';

@NgModule({
  declarations: [InitiativeComponent, InitiativeRequirementComponent, InitiativeFilterComponent],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class InitiativeModule { }
