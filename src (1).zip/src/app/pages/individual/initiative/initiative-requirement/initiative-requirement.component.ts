import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-initiative-requirement',
  templateUrl: './initiative-requirement.component.html',
  styleUrls: ['./initiative-requirement.component.css']
})
export class InitiativeRequirementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
