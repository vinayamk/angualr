import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitiativeRequirementComponent } from './initiative-requirement.component';

describe('InitiativeRequirementComponent', () => {
  let component: InitiativeRequirementComponent;
  let fixture: ComponentFixture<InitiativeRequirementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitiativeRequirementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiativeRequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
