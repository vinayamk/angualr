export interface InitiativeViewInterface{

    category:string,
    id:string,
    name:string,
    type:string;

}