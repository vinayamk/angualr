export interface FinalRequirementSubmitInterface{
    initiativeId:string,
    requirements:RequirementInterface[]


}

export interface RequirementInterface{

    requirementId:number,
    requirementDeleteStatus:number,
    level1OrgId:number,
    level2OrgId:number,
    level3OrgId:number,
    headCount:number,
    startDate:string,
    endDate:string,
    skills:SkillInterface[]

 


}

export interface SkillInterface{

    id:number,
    skillId:number,
    experienceRange:string,
    level:number,
    skillDeleteStatus:number
}