import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitiativeFilterComponent } from './initiative-filter.component';

describe('InitiativeFilterComponent', () => {
  let component: InitiativeFilterComponent;
  let fixture: ComponentFixture<InitiativeFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitiativeFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiativeFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
