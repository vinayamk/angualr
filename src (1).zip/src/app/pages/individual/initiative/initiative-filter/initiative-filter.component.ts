import { Component, OnInit } from '@angular/core';
import { InitiativeViewInterface } from '../interfaces/initiative.view.interface'
import { AuthGuard } from 'src/app/guards/auth.guard';
import { FinalRequirementSubmitInterface } from "../interfaces/final-requirement-submit.interface"
@Component({
  selector: 'app-initiative-filter',
  templateUrl: './initiative-filter.component.html',
  styleUrls: ['./initiative-filter.component.css']
})
export class InitiativeFilterComponent implements OnInit {

  constructor(private authGuard:AuthGuard ) {
     this.authGuard.loader=false;
     this.selectedInitiativeList=[{
       "id":'',
       "name":'',
       "category":"",
       "type":''
     }]


    this.finalRequirementSubmit={
      "initiativeId":"",
        "requirements":[{
          "requirementId":1,
          "requirementDeleteStatus":2,
          "level1OrgId":2,
          "level2OrgId":4,
          "level3OrgId":6,
           "headCount":4,
           "startDate":'',
           "endDate":'',
           "skills":[{
                "id":1,
    "skillId":4,
    "experienceRange":"dsds",
    "level":4,
    "skillDeleteStatus":2
           }]
         


        }]

    }

   }

  selectedInitiative:String;
  initiativeList:InitiativeViewInterface[];
  selectedInitiativeList:InitiativeViewInterface[];
  finalRequirementSubmit:FinalRequirementSubmitInterface;
  ngOnInit() {
    this.initiativeList = [{"id":"1","category":"Initaivive",'name':"sa","type":"sdsds"},
    {"id":"2","category":"Initaivive1",'name':"test","type":"sdsds"},
    {"id":"3","category":"Initaivive2",'name':"bmbsm","type":"sdsds"}]

      this.finalRequirementSubmit={
      "initiativeId":"",
        "requirements":[{
          "requirementId":1,
          "requirementDeleteStatus":2,
          "level1OrgId":2,
          "level2OrgId":4,
          "level3OrgId":6,
           "headCount":4,
           "startDate":'',
           "endDate":'',
           "skills":[{
                "id":1,
    "skillId":4,
    "experienceRange":"dsds",
    "level":4,
    "skillDeleteStatus":2
           }]
         


        },
        {
          "requirementId":1,
          "requirementDeleteStatus":2,
          "level1OrgId":2,
          "level2OrgId":4,
          "level3OrgId":6,
           "headCount":4,
           "startDate":'',
           "endDate":'',
           "skills":[{
                "id":1,
    "skillId":4,
    "experienceRange":"dsds",
    "level":4,
    "skillDeleteStatus":2
           }]
         


        }]

    }
   
  }

  getInitative(){
    this.selectedInitiativeList =  this.initiativeList.filter((data=>data.id==this.selectedInitiative))
    
  }


}
