import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IndividualSkillComponent } from './individual-skill/individual-skill.component';

import { IndividualJobRoleComponent } from './individual-job-role/individual-job-role.component';
import { PagenotfoundComponent } from '../pagenotfound/pagenotfound.component';
import { IndividualComponent } from './individual.component';
import { RoleGuard } from '../../guards/role.guard';
import { AuthGuard } from '../../guards/auth.guard';
import { DeactivateGuard } from '../../guards/deactivate.guard';

import { InitiativeComponent } from './initiative/initiative.component';
const routes: Routes = [
  { path: 'individual', component: IndividualComponent,
  children:[
      { path: '', redirectTo: 'skills', pathMatch: 'full' },
      { path: 'skills', component: IndividualSkillComponent, canActivate: [AuthGuard,RoleGuard], canDeactivate:[DeactivateGuard]},
      { path: 'jobrole', component: IndividualJobRoleComponent, canActivate: [AuthGuard,RoleGuard], canDeactivate: [DeactivateGuard]},
       { path: 'initiative', component: InitiativeComponent, canActivate: [AuthGuard,RoleGuard], canDeactivate: [DeactivateGuard]}
    ]

  },
   
  { path: 'pagenotfound', pathMatch: 'full' ,component:PagenotfoundComponent},
  { path:"**",redirectTo:'pagenotfound',pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
   providers:[AuthGuard,RoleGuard,DeactivateGuard]
})
export class IndividualRoutingModule { }
