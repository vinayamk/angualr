import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxBarRatingNewModule } from 'ngx-bar-rating-new';

import { IndividualSkillComponent } from './individual-skill/individual-skill.component';
import { IndividualRoutingModule } from './individual-routing.module';
import { IndividualSkillDialogComponent } from './individual-skill-dialog/individual-skill-dialog.component';
import { MaterialModule } from '../../shared/material-module';
import { IndividualJobRoleComponent } from './individual-job-role/individual-job-role.component';
import { IndividualJobRoleDialogComponent } from './individual-job-role-dialog/individual-job-role-dialog.component';
import { IndividualSkillService } from './individual-skill/individual-skill.service';
import { SkillProficiencyDialogComponent } from './skill-proficiency-dialog/skill-proficiency-dialog.component';
import { PagenotfoundComponent } from '../pagenotfound/pagenotfound.component';
import { IndividualComponent } from './individual.component';
import { CoreModule } from '../../core/core.module';
import { InitiativeModule } from './initiative/initiative.module';
@NgModule({
  declarations: [
    IndividualSkillComponent,
    IndividualSkillDialogComponent,
    IndividualJobRoleComponent,
    IndividualJobRoleDialogComponent,
    SkillProficiencyDialogComponent,
    PagenotfoundComponent,
    IndividualComponent
  ],
  imports: [
    CommonModule,
    IndividualRoutingModule,
    FormsModule,
    MaterialModule,
    NgxBarRatingNewModule,
    ReactiveFormsModule,
    CoreModule,
    InitiativeModule
  ],
  exports: [
  ],
  providers: [
    IndividualSkillService
  ],
  entryComponents: [
    IndividualSkillDialogComponent,
    IndividualJobRoleDialogComponent,
    SkillProficiencyDialogComponent
  ]
})
export class IndividualModule { }
