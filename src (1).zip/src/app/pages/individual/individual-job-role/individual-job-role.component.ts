import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { JobRoleGrade } from '../job-role-interface/job-role-grade';
import { JobRoleTeamSize } from '../job-role-interface/job-role-team-size';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { IndividualJobRoleService } from './individual-job-role.service';
import { IndividualJobRoleDialogComponent } from '../individual-job-role-dialog/individual-job-role-dialog.component';
import { UserService } from 'src/app/core/services/user.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AuthGuard } from '../../../guards/auth.guard';
import { Observable } from 'rxjs';
import { DataStoreService, SKILL_CLASSIFICATION_VALUES } from 'src/app/core/services/data-store.service';



export interface InitialMasterObject {
  experienceId: number;
  jobLevels: any[];
  jobRoleId: number;
  numberOfProjects: number;
  peakTeamSizeId: number;

}


export interface ViewModelJobRole {
  experienceId: number;
  FinalexperienceId: number;
  JobRolename: string;
  SpecalityField: string;
  JobRoleId: number;
  numberOfProjects: number;
  FinalnumberOfProjects: number;
  peakTeamSizeId: number;
  FinalpeakTeamSizeId: number;
  description: string;

}

export interface JobRoleV {
  jobRoleId: number;
  experienceId: number;
  peakTeamSizeId: number;
  numberofProjects: number;
}
export interface JobRoleSubmit {
  employeeId: string;
  jobs: JobRoleV[];
}


//Author      : Ganesh.kanakala
//Description : Survey B - JobRoles

@Component({
  selector: 'app-individual-job-role',
  templateUrl: './individual-job-role.component.html',
  styleUrls: ['./individual-job-role.component.css']
})


export class IndividualJobRoleComponent implements OnInit {

  displayedColumns1: any[] = ['No', "SpecalityField", "experienceId"];
  displayedColumns: any[] = ["No", "JobRolename", "SpecalityField", "description", "experienceId"];
  dataSource1: any[];
  dataSource: any[];
  jobgradeList: any[];
  jobPMTeamSizeList: any[];
  ViewModelJobRole: ViewModelJobRole;
  InitilaMasterJobRoleList: InitialMasterObject[];
  MasterTechnicalJobRoleList: ViewModelJobRole[];
  MasterPMjobRoleList: ViewModelJobRole[];
  MasterPMObject: ViewModelJobRole;
  MasterTSObject: ViewModelJobRole;
  MasterPMViewObject: ViewModelJobRole;
  MasterTSViewObject: ViewModelJobRole;
  FinalSaveObject: any;
  FinalSaveObjectList: ViewModelJobRole[];
  JobRoleSubmitObject: JobRoleSubmit;
  JobRolEoBJ: JobRoleV;
  formGroup: FormGroup;
  isDisabledButtons: boolean;
  employeeid: string;
  // TODO: Comments
  isCycleOpen: boolean;


  MatToolValueArray: any[] = ["1 .Design proposal and performs  initiation, planning and execution of an IT project \r\n  2.Manage customer  interactions and handling project team including external contractors to meet varied IT requirements along with Non Functional requirements \r\n 3 .Responsible for the quality, cost, and delivery of scheduled deliverables by managing risks / issues to meet KPIs using defined processes"];

  matvaluetip: any;

  constructor(private authGuard: AuthGuard, private formBuilder: FormBuilder, private _snackBar: MatSnackBar, public dialog: MatDialog, private IndividualJobRoleService: IndividualJobRoleService, private userService: UserService, private dataStoreService: DataStoreService,) {
    this.authGuard.loader = true;
  }

  ngOnInit() {
    this.isDisabledButtons = true;
    this.formGroup = this.formBuilder.group({
      'noOfProjects': [null],
      'teamSize': [null]
    });

    /** Initialize the JobRole Object */
    this.JobRoleSubmitObject = {
      employeeId: '',
      jobs: []
    }

    /** Initialize the JobRoleI Object */
    this.JobRolEoBJ = {
      jobRoleId: 0,
      experienceId: 0,
      peakTeamSizeId: 0,
      numberofProjects: 0
    }

    // TODO: Comments
    this.dataStoreService.cycleBehaviorSubject
      .subscribe((data: boolean) => {
        this.isCycleOpen = data;
      })

    this.dataStoreService.GIDBehaviorSubject
      .subscribe((data: string) => {
        this.JobRoleSubmitObject.employeeId = data;
        this.employeeid = data;
      });

    // Get User GID from User Service
    //this.userService.gIdSubject
    //  .subscribe((data: string) => {
    //    this.JobRoleSubmitObject.employeeId = data;
    //    this.employeeid = data;
    //  });

    // tooltip
    this.matvaluetip = this.MatToolValueArray.join("\r\n");
    //get peak project team size list
    this.getProjectPeakTeamSizeList();

    //get jobrole grade list
    this.getJobRoleGradeList();

  }

  saveData() {

    this.JobRoleSubmitObject.employeeId = this.employeeid;
    if (!this.checkProjectManagement()) {
      return;
    }
    

    if (this.JobRoleSubmitObject.jobs.length != 0) {
      this.IndividualJobRoleService.saveJobRole(this.JobRoleSubmitObject)
        .subscribe(data => {
          this.openSnackBar();

          this.getJobRoleMasterList();

          this.isDisabledButtons = true;
          this.JobRoleSubmitObject = {
            employeeId: '',
            jobs: []
          }
          
          
        }, error => console.log(error));
    }


  }


  resetData() {


    this.MasterTechnicalJobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] != "Project Management").map(obj => this.PrepareListObjects(obj)).sort(function (a, b) { return b.experienceId - a.experienceId });
    this.MasterPMjobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] != "Total # of PJs managed" && t.jobLevels[1] != "Peak Team Size").map(obj => this.PrepareListObjects(obj));

    this.formGroup = this.formBuilder.group({
      'noOfProjects': [Number(this.MasterPMObject.numberOfProjects)],
      'teamSize': [Number(this.MasterTSObject.peakTeamSizeId)]
    });

    this.dataSource = this.MasterTechnicalJobRoleList;
    this.dataSource1 = this.MasterPMjobRoleList;

    this.isDisabledButtons = true;


    this._snackBar.open("Job Role Cancelled", "Close", {
      duration: 2000,
      verticalPosition: 'top',
    });

    this.JobRoleSubmitObject = {
      employeeId: '',
      jobs: []
    }


  }

  openSnackBar() {
    this._snackBar.open("Job Role Saved successfully", "Close", {
      duration: 2000,
      verticalPosition: 'top',
    });
  }


  onJobRoleChanged(jobrole: ViewModelJobRole, JobroleGrade) {

    jobrole.FinalexperienceId = JobroleGrade;
    jobrole.peakTeamSizeId = 0;
    jobrole.numberOfProjects = 0;

    // Remove the job from job object if initial and final experience are the same
    if (jobrole.FinalexperienceId === jobrole.experienceId) {
      this.JobRoleSubmitObject.jobs = this.JobRoleSubmitObject.jobs.filter((JobRoleInSubmitObject) => {
        if (JobRoleInSubmitObject.jobRoleId !== jobrole.JobRoleId) {
          return JobRoleInSubmitObject;
        }
      })
      return;
    }

   

    let isJobInFinalObject: boolean;

    this.JobRolEoBJ = {
      jobRoleId: jobrole.JobRoleId,
      experienceId: jobrole.FinalexperienceId,
      peakTeamSizeId: jobrole.peakTeamSizeId,
      numberofProjects: jobrole.FinalnumberOfProjects
    }


    // Update the rating of the job if job is already present in the final object
    this.JobRoleSubmitObject.jobs.filter((skillInSubmitObject) => {
      if (skillInSubmitObject.jobRoleId === jobrole.JobRoleId) {
        skillInSubmitObject.experienceId = jobrole.FinalexperienceId;
        isJobInFinalObject = true;
      }
    })

    // Add the job into the final object if not present initially
    if (!isJobInFinalObject) {
      this.JobRoleSubmitObject.jobs.push(this.JobRolEoBJ);
    }

    this.checkDisableBtn();

  }

  onPMChangedD(ProjectsManagedNo)
  {
    console.log(ProjectsManagedNo);
    if (!((ProjectsManagedNo.keyCode > 95 && ProjectsManagedNo.keyCode < 106)
      || (ProjectsManagedNo.keyCode > 47 && ProjectsManagedNo.keyCode < 58)
      || ProjectsManagedNo.keyCode == 8
      || ProjectsManagedNo.keyCode == 9)) {
      return false;
    }

     if (String(ProjectsManagedNo.target.value).length >= 3) {
       if (ProjectsManagedNo.keyCode == 8 || ProjectsManagedNo.keyCode == 9)
        return true
      else
        return false
    }

  }

  onPMChanged(ProjectsManagedNo, jobrole: ViewModelJobRole) {

    jobrole.FinalnumberOfProjects = Number(ProjectsManagedNo.target.value);
    jobrole.experienceId = 0;
    jobrole.peakTeamSizeId = 0;

    // Remove the job from job object if initial and final number of projects are the same
    if (jobrole.FinalnumberOfProjects === jobrole.numberOfProjects) {
      this.JobRoleSubmitObject.jobs = this.JobRoleSubmitObject.jobs.filter((JobRoleInSubmitObject) => {
        if (JobRoleInSubmitObject.jobRoleId !== jobrole.JobRoleId) {
          return JobRoleInSubmitObject;
        }
      })
      return;
    }

    let isJobInFinalObject: boolean;

    this.JobRolEoBJ = {
      jobRoleId: jobrole.JobRoleId,
      experienceId: jobrole.FinalexperienceId,
      peakTeamSizeId: jobrole.peakTeamSizeId,
      numberofProjects: jobrole.FinalnumberOfProjects
    }


    // Update the rating of the job if job is already present in the final object
    this.JobRoleSubmitObject.jobs.filter((skillInSubmitObject) => {
      if (skillInSubmitObject.jobRoleId === jobrole.JobRoleId) {
        skillInSubmitObject.numberofProjects = jobrole.FinalnumberOfProjects;
        isJobInFinalObject = true;
      }
    })

    // Add the job into the final object if not present initially
    if (!isJobInFinalObject) {
      this.JobRoleSubmitObject.jobs.push(this.JobRolEoBJ);
    }

    this.checkDisableBtn();
  }

  onTeamSizeSelection(TeamSize, jobrole: ViewModelJobRole) {
    jobrole = this.MasterTSObject;

    jobrole.FinalpeakTeamSizeId = TeamSize;
    jobrole.experienceId = 0;
    jobrole.numberOfProjects = 0;

    // Remove the job from job object if initial and final number of projects are the same
    if (jobrole.FinalpeakTeamSizeId === jobrole.peakTeamSizeId) {
      this.JobRoleSubmitObject.jobs = this.JobRoleSubmitObject.jobs.filter((JobRoleInSubmitObject) => {
        if (JobRoleInSubmitObject.jobRoleId !== jobrole.JobRoleId) {
          return JobRoleInSubmitObject;
        }
      })
      return;
    }

    

    let isJobInFinalObject: boolean;

    this.JobRolEoBJ = {
      jobRoleId: jobrole.JobRoleId,
      experienceId: jobrole.FinalexperienceId,
      peakTeamSizeId: jobrole.FinalpeakTeamSizeId,
      numberofProjects: jobrole.FinalnumberOfProjects
    }


    // Update the rating of the job if job is already present in the final object
    this.JobRoleSubmitObject.jobs.filter((skillInSubmitObject) => {
      if (skillInSubmitObject.jobRoleId === jobrole.JobRoleId) {
        skillInSubmitObject.peakTeamSizeId = jobrole.FinalpeakTeamSizeId;
        isJobInFinalObject = true;
      }
    })

    // Add the job into the final object if not present initially
    if (!isJobInFinalObject) {
      this.JobRoleSubmitObject.jobs.push(this.JobRolEoBJ);
    }

    this.checkDisableBtn();

  }

  checkDisableBtn() {
    if (this.JobRoleSubmitObject.jobs.length == 0)
      this.isDisabledButtons = true;
    else
      this.isDisabledButtons = false;
  }

  


  openJobRoleSummaryDialog() {
    const dialogConfig = new MatDialogConfig();
    const dialogRef = this.dialog.open(IndividualJobRoleDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      //console.log(`Dialog result: ${result}`);
    });
  }

  // Master data logic

  getJobRoleMasterMainObject(MainList) {
    this.InitilaMasterJobRoleList = [];
    this.InitilaMasterJobRoleList = MainList as InitialMasterObject[];
    this.MasterPMjobRoleList = [];
    this.MasterTechnicalJobRoleList = [];
    this.MasterTechnicalJobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] != "Project Management").map(obj => this.PrepareListObjects(obj)).
      sort(function (a, b) {
        return b.experienceId - a.experienceId; // a.experienceId - b.experienceId && b.JobRoleId - a.JobRoleId;
    });
    this.MasterPMjobRoleList = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] != "Total # of PJs managed" && t.jobLevels[1] != "Peak Team Size").map(obj => this.PrepareListObjects(obj));
    this.MasterPMObject = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] == "Total # of PJs managed").map(obj => this.PrepareListObjects(obj))[0];
    this.MasterTSObject = this.InitilaMasterJobRoleList.filter(t => t.jobLevels[0] == "Project Management" && t.jobLevels[1] == "Peak Team Size").map(obj => this.PrepareListObjects(obj))[0];

    this.dataSource = this.MasterTechnicalJobRoleList;
    this.dataSource1 = this.MasterPMjobRoleList;


    this.formGroup = this.formBuilder.group({
      'noOfProjects': [Number(this.MasterPMObject.numberOfProjects)],
      'teamSize': [Number(this.MasterTSObject.peakTeamSizeId)]
    });
  }


  PrepareListObjects(obj) {

    this.ViewModelJobRole = {
      experienceId: 0,
      FinalexperienceId: 0,
      JobRolename: "",
      SpecalityField: "",
      JobRoleId: 0,
      numberOfProjects: 0,
      FinalnumberOfProjects: 0,
      peakTeamSizeId: 0,
      FinalpeakTeamSizeId: 0,
      description: ""
    };
    this.ViewModelJobRole.experienceId = obj.experienceId;
    this.ViewModelJobRole.FinalexperienceId = obj.experienceId;
    this.ViewModelJobRole.JobRolename = obj.jobLevels[0];
    this.ViewModelJobRole.SpecalityField = obj.jobLevels[1];
    this.ViewModelJobRole.numberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.FinalnumberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.FinalnumberOfProjects = obj.numberOfProjects;
    this.ViewModelJobRole.peakTeamSizeId = obj.peakTeamSizeId;
    this.ViewModelJobRole.FinalpeakTeamSizeId = obj.peakTeamSizeId;
    this.ViewModelJobRole.JobRoleId = obj.jobRoleId;
    this.ViewModelJobRole.description = obj.description;

    return this.ViewModelJobRole
  }

  //get Project peak team size List

  getProjectPeakTeamSizeList() {

    this.IndividualJobRoleService.getJobRoleTeamSize()
      .subscribe(data => {
        this.jobPMTeamSizeList = data as JobRoleTeamSize[];
       
      }, error => console.log(error));

  }

  //get Project peak team size List

  getJobRoleGradeList() {

    this.IndividualJobRoleService.getJobRoleGrades()
      .subscribe(data => {
        this.jobgradeList = data as JobRoleGrade[];

        // TODO: Refine this
        this.jobgradeList.unshift({
          id: 0,
          value: 'N/A'
        });

        this.getJobRoleMasterList();

      },
        error => console.log(error));

  }

  // Get JobRole Master List

  getJobRoleMasterList() {

    this.IndividualJobRoleService.getJobRoleList()
      .subscribe(data => {

        this.getJobRoleMasterMainObject(data);
        this.authGuard.loader = false;
      },
        error => console.log(error));

  }

  // TODO: Comments
  canDeactivate(): Observable<boolean> | boolean {
    let userOption: boolean;
    if (this.JobRoleSubmitObject.jobs.length !== 0) {
      userOption = window.confirm('The data you updated on this page (Survey B) will be lost, if you leave the page. Do you want to continue?');
      if (!userOption) {
        return false;
      }

    }
    return true;
  }


  checkProjectManagement() {

    var PrepareMessage = '';
    var lengthOfPMList = this.dataSource1.filter(t => t.FinalexperienceId != 0).length;

    if ((this.formGroup.value["noOfProjects"] == 0 || this.formGroup.value["noOfProjects"] == null ) && this.formGroup.value["teamSize"] == 0 && lengthOfPMList == 0) {
      return true;
    }
    else {

      if ((this.formGroup.value["noOfProjects"] == 0 || this.formGroup.value["noOfProjects"] == null) || this.formGroup.value["teamSize"] == 0 || lengthOfPMList == 0) {
        PrepareMessage = "Note: To update experience for project management related job role, please ensure to update all of the following  \n\n 1. No of Project's : " + ((this.formGroup.value["noOfProjects"] != 0 && this.formGroup.value["noOfProjects"] != null) ? this.formGroup.value["noOfProjects"] : " Please fill the Value ") +
          "\n 2. Project Team Size : " + (this.formGroup.value["teamSize"] != 0 ? " Selected " : " Please Select a Value ") +
          "\n 3. Project Budget Category : " + (lengthOfPMList != 0 ? " Selected \n" : "Please Select a Value \n");
        
        alert(PrepareMessage);
        return false;
      }
      else {
        return true;
      }
     
    }
  }


}
