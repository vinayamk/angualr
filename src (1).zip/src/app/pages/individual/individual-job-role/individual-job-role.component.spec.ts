import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualJobRoleComponent } from './individual-job-role.component';

describe('IndividualJobRoleComponent', () => {
  let component: IndividualJobRoleComponent;
  let fixture: ComponentFixture<IndividualJobRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualJobRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualJobRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
