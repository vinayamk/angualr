import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class IndividualJobRoleService {

  constructor(private http: HttpClient) { }
  
  getJobRoleGrades() {
    return this.http.get(
      environment.API.baseAPIURL + environment.API.SurveyB_JobRole_URLs.JobRoleGrades
    );
  }

  getJobRoleTeamSize() {
    return this.http.get(
      environment.API.baseAPIURL + environment.API.SurveyB_JobRole_URLs.PeakTeamSize
    );
  }

  getJobRoleList() {
    return this.http.get(
      environment.API.baseAPIURL + environment.API.SurveyB_JobRole_URLs.JobRoleList
    );
  }

  saveJobRole(JobroleObject) {
    return this.http.post(
      environment.API.baseAPIURL + environment.API.SurveyB_JobRole_URLs.SaveJobRole, JobroleObject
    );
  }
}
