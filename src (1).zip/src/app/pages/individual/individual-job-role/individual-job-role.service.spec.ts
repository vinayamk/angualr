import { TestBed } from '@angular/core/testing';

import { IndividualJobRoleService } from './individual-job-role.service';

describe('IndividualJobRoleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IndividualJobRoleService = TestBed.get(IndividualJobRoleService);
    expect(service).toBeTruthy();
  });
});
