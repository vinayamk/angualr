import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute,NavigationStart } from '@angular/router';
import { AuthGuard } from '../../guards/auth.guard';
@Component({
  selector: 'app-individual',
  templateUrl: './individual.component.html',
  styleUrls: ['./individual.component.css']
})
export class IndividualComponent implements OnInit {
 // title = 'skill-capability-web-app';
  loader:boolean=true;
  showOrHidePage:boolean=false;
   title = 'materialApp'; 
   color = 'primary';
   mode = 'indeterminate';
   value = 50;
  constructor(private http: HttpClient,private router: Router,
  
    private activatedRoute: ActivatedRoute,private authGuard:AuthGuard) {

          
    }

    ngOnInit(){
      
      
    }

}
