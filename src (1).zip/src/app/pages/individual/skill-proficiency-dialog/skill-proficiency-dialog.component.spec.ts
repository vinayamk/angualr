import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillProficiencyDialogComponent } from './skill-proficiency-dialog.component';

describe('SkillProficiencyDialogComponent', () => {
  let component: SkillProficiencyDialogComponent;
  let fixture: ComponentFixture<SkillProficiencyDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillProficiencyDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillProficiencyDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
