import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-skill-proficiency-dialog',
  templateUrl: './skill-proficiency-dialog.component.html',
  styleUrls: ['./skill-proficiency-dialog.component.css']
})
export class SkillProficiencyDialogComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<SkillProficiencyDialogComponent>) { }

  ngOnInit() {
  }

  /**
   * Closes the Pop-up.
   */
  closeDialog() {
    this.dialogRef.close();
  }
}
