import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HelpComponent } from './help.component';
import { MaterialModule } from '../../shared/material-module';
@NgModule({
  declarations: [HelpComponent],
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports:[HelpComponent]
})
export class HelpModule { }
