import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { ManagerDialogComponent } from '../manager-dialog/manager-dialog.component';

@Component({
  selector: 'app-manager-list',
  templateUrl: './manager-list.component.html',
  styleUrls: ['./manager-list.component.css']
})
export class ManagerListComponent implements OnInit {

  displayedColumns = ['position', 'name', 'org'];
  dataSource = ELEMENT_DATA;
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    //dialogConfig.width = "100%";  
    const dialogRef = this.dialog.open(ManagerDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}

export interface EmployeeList {
  name: string;
  position: number;
  org: string;
}

const ELEMENT_DATA: EmployeeList[] = [
  { position: 1, name: 'ganesh', org: "ADC"},
  { position: 2, name: 'raif', org: "ADC" },
  { position: 3, name: 'abdur', org: "ADC"},
  { position: 4, name: 'vishal', org: "ADC" },
  { position: 5, name: 'pradeep', org: "ADC" },
  { position: 6, name: 'saraiyu', org: "ADC" },
  { position: 7, name: 'sarvani', org: "ADC" },
  
];
