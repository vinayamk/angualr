import { Component, OnInit } from '@angular/core';

import { coerceNumberProperty } from '@angular/cdk/coercion';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-manager-dialog',
  templateUrl: './manager-dialog.component.html',
  styleUrls: ['./manager-dialog.component.css']
})
export class ManagerDialogComponent implements OnInit {

  // scale
  autoTicks = false;
  disabled = false;
  invert = false;
  max = 100;
  min = 0;
  showTicks = true;
  step = 1;
  thumbLabel = true;
  value = 0;
  vertical = false;


  get tickInterval(): number | 'auto' {
    return this.showTicks ? (this.autoTicks ? 'auto' : this._tickInterval) : 0;
  }
  set tickInterval(value) {
    this._tickInterval = coerceNumberProperty(value);
  }
  private _tickInterval = 1;

  events: string[] = [];
  opened: boolean;


  tabLoadTimes: Date[] = [];
  displayedColumns = ['position', 'Skill', 'Level3', 'ASIS', 'tobeNplusOne','tobeNplusThree'];
  dataSource = new MatTableDataSource(SKILL_DATA);

  getTimeLoaded(index: number) {
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  constructor() { }

  ngOnInit() {
  }

}

export interface SkillDetails {
  position: number;
  name: string;
  Skill: string;
  Level3: string;
  ASIS: number;
  tobeNplusOne: number,
  tobeNplusThree: number,
}



const SKILL_DATA: SkillDetails[] = [
  { position: 1, name: 'Ashish', Skill: "SAP Finance and Control", Level3: 'SAP', ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 2, name: 'Abhi', Skill: "SAP Vistex", Level3: 'SAP', ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 3, name: 'Ganesh', Skill: "S/4 HANA Finance ", Level3: 'SAP', ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 4, name: 'Subash', Skill: "ABAP on HANA", Level3: 'SAP', ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 5, name: 'Rehman', Skill: "SAP HANA Database", Level3: 'SAP', ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 6, name: 'salabha', Skill: "UI/UX development (Fiori)", Level3: "SAP", ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 7, name: 'salabha', Skill: "UI/UX development (Fiori)", Level3: "SAP", ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 8, name: 'salabha', Skill: "UI/UX development (Fiori)", Level3: "SAP", ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 9, name: 'salabha', Skill: "UI/UX development (Fiori)", Level3: "SAP", ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
  { position: 10, name: 'salabha', Skill: "UI/UX development (Fiori)", Level3: "SAP", ASIS: 4, tobeNplusOne: 6, tobeNplusThree: 8 },
];
