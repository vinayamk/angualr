import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
   public loggingStatusSubject = new BehaviorSubject(true);
  constructor(private http: HttpClient) {}

  checkUserAccess(){
    return this.http.get(
          environment.API.baseAPIURL+environment.API.AuthorizationApi
      );;
  }

  getLoggingStatusSubject(){
    return this.loggingStatusSubject.asObservable();
  }

  saveLoggingStatusSubject(status){
  
    this.loggingStatusSubject.next(status);
  }
}
