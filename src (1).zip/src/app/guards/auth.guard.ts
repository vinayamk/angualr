import { Injectable } from '@angular/core';
import { CanActivate,
         ActivatedRouteSnapshot,
         RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';

import { MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
@Injectable()
export class AuthGuard implements CanActivate {
  public loader = false;
  constructor(private router: Router,private adalService: MsAdalAngular6Service) {
     this.loader = true;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
   
        if (this.adalService.isAuthenticated) {
            return true;
        } else {
          this.adalService.login();
          return false;
        }

  }
}