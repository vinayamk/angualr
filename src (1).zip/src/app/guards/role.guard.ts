import { Injectable } from '@angular/core';
import { CanActivate,
         ActivatedRouteSnapshot,
         RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { AuthorizationService } from '../services/authorization.service';
import { Observable } from 'rxjs';
@Injectable()
export class RoleGuard implements CanActivate {

  constructor(private router: Router,private authorizationService:AuthorizationService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
   
      return new Promise((resolve, reject) => {
       this.authorizationService.checkUserAccess().subscribe(data=>{
          if(data){
           resolve(true);
          }else{
            
              this.authorizationService.saveLoggingStatusSubject(false);
              this.router.navigate(['/unauthorized']);
              resolve(false);
          }
       
       })
      })
      
     //  return true;
       //
  }
}