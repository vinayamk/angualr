import { Component, OnInit } from '@angular/core';

import { UserService } from '../services/user.service';
import { UserAndOrgDetailInterface } from '../interfaces/user-detail.interface';
@Component({
  selector: 'app-user-org-level',
  templateUrl: './user-org-level.component.html',
  styleUrls: ['./user-org-level.component.css']
})
export class UserOrgLevelComponent implements OnInit {
  //userOrgLevelDetails:UserAndOrgDetailInterface;
  userOrgLevelDetails:UserAndOrgDetailInterface;
  constructor(private userService: UserService) {

 //  this.userOrgLevelDetails=[""];
  }

  showOrgDetails:boolean=false;
  ngOnInit() {
  
      this.userService.getUserDetails().subscribe((data:UserAndOrgDetailInterface) => this.userOrgLevelDetails=data, error => console.log(error));
  }

  showHideOrgDetails(){

    this.showOrgDetails = !this.showOrgDetails;
  }
}
