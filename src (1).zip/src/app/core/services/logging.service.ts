import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ErrorLogInterface } from '../interfaces/error-log.interface';
import { DataStoreService } from './data-store.service';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class LoggingService {
    /** The GID of the logged in user. To be sent to the log file. May be empty if GID  */
    GID: string;

    constructor(private http: HttpClient,
                private dataStoreService: DataStoreService) {
        this.dataStoreService.GIDBehaviorSubject
            .subscribe((data: string) => {
                this.GID = data;
            });
    }

    submitErrorLogsAPI(error: Error) {
        console.log(error.name);
        let errorDetails: ErrorLogInterface = {
            // TODO: Check what code to send
            Code: 1,
            Message: error.message,
            MailId: this.GID,
            Details: error.stack
        }

        return this.http.post(
            environment.API.baseAPIURL + environment.API.SurveyA_Skills_API_URLs.POSTRequestURLs.SubmitErrorLogs,
            errorDetails, {
                responseType: 'text'
            }
        );
    }
}
