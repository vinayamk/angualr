import { Injectable } from '@angular/core';
import { AuthorizationService } from '../../services/authorization.service';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { LoggingService } from './logging.service';

@Injectable({
  providedIn: 'root'
})

export class HttpErrorInterceptor implements HttpInterceptor {
  constructor(private loggingService: LoggingService,private authorizationService:AuthorizationService) {}
  
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(
        retry(1),
        catchError((error: HttpErrorResponse) => {
      
         this.authorizationService.getLoggingStatusSubject().subscribe(data=>{
          
            if(data){
                this.loggingService.submitErrorLogsAPI(error);  
           }

          })
         // this.loggingService.submitErrorLogsAPI(error);
          return throwError(error);
        })
      )
  }
}