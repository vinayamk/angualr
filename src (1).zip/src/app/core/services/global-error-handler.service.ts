import { ErrorHandler, Injectable} from '@angular/core';
import { LoggingService } from './logging.service';
import { AuthorizationService } from '../../services/authorization.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private loggingService: LoggingService,private authorizationService:AuthorizationService) { }

  handleError(error: Error) {

    
         this.authorizationService.getLoggingStatusSubject().subscribe(data=>{
          
            if(data){
              this.loggingService.submitErrorLogsAPI(error).subscribe(data => {
               console.log(data);
            }, error => console.log(error));
           }

          })
   // this.loggingService.submitErrorLogsAPI(error)
    
  }  
}