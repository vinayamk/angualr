import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserService {

 public gIdSubject = new BehaviorSubject(null);
  constructor(private http: HttpClient) {}


  getUserDetails() {
    console.log( environment.API.baseAPIURL+environment.API.UserInfo_API_URLs.GETRequestURLs.UserInfo)
      return this.http.get(
          environment.API.baseAPIURL+environment.API.UserInfo_API_URLs.GETRequestURLs.UserInfo
      );
  }

  /** Save Gid in subject and will be  used by all APIs */
  saveGID(id:string){
    this.gIdSubject.next(id);
  }

  getGID():Observable<string> {
    return this.gIdSubject.asObservable();
  }

  checkUserAccess(){
    return this.http.get(
          environment.API.baseAPIURL+environment.API.AuthorizationApi
      );
  }

  checkIsCycleIdActive(){
    return this.http.get(
          environment.API.baseAPIURL+environment.API.IsCycleIdActiveAPi
      );
  }

}
