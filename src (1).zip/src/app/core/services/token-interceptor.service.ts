import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {
  constructor(private adalService: MsAdalAngular6Service) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if(this.adalService.isAuthenticated) {
      
      const modifiedRequest = request.clone({
        headers: request.headers
          .append(environment.API.headerNamesInInterceptor.Authorization, 
            `Bearer ${this.adalService.accessToken}`)
          .append(environment.API.headerNamesInInterceptor.SubscriptionKeyName, 
            environment.API.SubscriptionKeyValue)
      });
      return next.handle(modifiedRequest);
    }
    else {
      this.adalService.login();
    }
  }
}
