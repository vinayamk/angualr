import { Injectable } from '@angular/core';
import { AllSkillsWithClassificationInterface } from 'src/app/pages/individual/interfaces/all-skills-with-classifications.interface';
import { SelectedSkillsWithClassificationInterface } from 'src/app/pages/individual/interfaces/selected-skills-with-classifications.interface';
import { SkillCategoryInterface } from 'src/app/pages/individual/interfaces/skill-category.interface';
import { FirstAndSecondCategoryInterface } from 'src/app/pages/individual/interfaces/first-and-second-category.interface';
import { RatingValuesInterface } from 'src/app/pages/individual/interfaces/rating-value.interface';
import { BehaviorSubject } from 'rxjs';

// Hardcoded - For Skill Classification Filter
export const SKILL_CLASSIFICATION_VALUES = [
  'Basic',
  'Specialist',
  'Emerging'
];

@Injectable({
  providedIn: 'root'
})
export class DataStoreService {
  /** Contains all the skills with classifications as per AllSkillsWithClassificationInterface. */
  allSkillsWithClassification: AllSkillsWithClassificationInterface;

  /** Contains the selected skills with classifications as per SelectedSkillsWithClassificationInterface. */
  selectedSkillsWithClassification: SelectedSkillsWithClassificationInterface;

  /** Contains the names of the skill level category. */
  skillCategoryNames: SkillCategoryInterface;

  /** Holds first category skills mapped to their respective second category skills. */
  firstAndSecondCategorySkills: FirstAndSecondCategoryInterface[];

  /** The rating values to be displayed in the rating bar. */
  ratingValuesList: RatingValuesInterface[];

  /** Holds the value of the logged in user GID. */
  GIDBehaviorSubject: BehaviorSubject<string>;

  /** Holds the value of the current cycle, open or closed. */
  cycleBehaviorSubject: BehaviorSubject<boolean>;

  constructor() { 
    this.allSkillsWithClassification = {
      initialSkills: [],
      finalSkills: [],
      selectedSkills: [],
      unSelectedSkills: []
    }

    this.selectedSkillsWithClassification = {
      initialSkills: [],
      finalSkills: []
    }

    this.initializeSkillCategoryNames();

    this.firstAndSecondCategorySkills = [];

    this.ratingValuesList = [];

    this.GIDBehaviorSubject = new BehaviorSubject('');
    this.cycleBehaviorSubject = new BehaviorSubject(false);
  }

  initializeSkillCategoryNames() {
    this.skillCategoryNames = {
      firstCategoryName: '',
      secondCategoryName: '',
      thirdCategoryName: '',
      fourthCategoryName: '',
      fifthCategoryName: ''
    }
  }

  checkIfEmptySkillsWithClassifications(): boolean {
    if(this.allSkillsWithClassification.initialSkills.length === 0)  {
      return true;
    }
    return false;
  }

  checkIfEmptySkillCategoryNames(): boolean {
    if(this.skillCategoryNames.firstCategoryName === '') {
      return true;
    }
    return false;
  }

  checkIfEmptyFirstAndSecondCategorySkills(): boolean {
    if(this.firstAndSecondCategorySkills.length === 0) {
      return true;
    }
    return false;
  }

  checkIfEmptyRatingValuesList(): boolean {
    if(this.ratingValuesList.length === 0) {
      return true;
    }
    return false;
  }

  /**
   * Checks if all the API data required for Skills Page is loaded in the Data Store.
   */
  checkIfAllSkillsComponentDataLoaded() {
    let isNotLoaded: boolean = this.checkIfEmptySkillCategoryNames() ||
      this.checkIfEmptyFirstAndSecondCategorySkills() ||
      this.checkIfEmptyRatingValuesList() ||
      this.checkIfEmptySkillsWithClassifications();

    return !isNotLoaded;
  }
}