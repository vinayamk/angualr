import { Component, OnInit,Inject } from '@angular/core';
import { Router, ActivatedRoute,NavigationStart,NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';

import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {HelpComponent} from "../../pages/help/help.component";
import {ContactDialogComponent} from "../../pages/contact/contact-dialog/contact-dialog.component";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})


export class HeaderComponent implements OnInit {

  selectedRoute:string;
  constructor(private adalService: MsAdalAngular6Service,public dialog: MatDialog,
              private router: Router,
              private activatedRoute: ActivatedRoute) {
  
  this.router.events.subscribe((event) => {
     // console.log(event.NavigationEnd);
    if (event instanceof NavigationEnd) {
      
       if(event.url == '/individual/jobrole'){
         this.selectedRoute = "Survey B - Job Role";
         
       }else{
         this.selectedRoute = "Survey A - Skills";
       }
      
      
    }
  });
}

  ngOnInit() {

  }

  onLogout(): void {
    this.adalService.logout();
  }


 openDialog(): void {
    const dialogRef = this.dialog.open(HelpComponent, {
       height: '500px',
        width: '800px',
     
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
    });
  }

   openContactDialog(): void {
    const dialogRef = this.dialog.open(ContactDialogComponent, {
       height: '265px',
        width: '400px',
    
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
    });
  }
}

