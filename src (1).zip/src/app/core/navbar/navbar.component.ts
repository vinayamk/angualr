import { Component, OnInit } from '@angular/core';

import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AuthGuard } from 'src/app/guards/auth.guard';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  username: string;

  isMaxWidth: boolean;
  isMaxWidthFixed: boolean;

  constructor(private adalService: MsAdalAngular6Service,
              private authGuard: AuthGuard) {}

  ngOnInit() {
    this.username = this.adalService.LoggedInUserName;
    console.log(this.username);
  }
}
