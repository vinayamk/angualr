import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MaterialModule } from '../shared/material-module';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { UserOrgLevelComponent } from './user-org-level/user-org-level.component';
import { ContactDialogComponent } from '../pages/contact/contact-dialog/contact-dialog.component';
import { ContactModule } from '../pages/contact/contact.module';
import { HelpModule } from '../pages/help/help.module';
import { HelpComponent } from '../pages/help/help.component';

@NgModule({
  declarations: [
    HeaderComponent, 
    FooterComponent,
    NavbarComponent,
    UserDetailComponent,
    UserOrgLevelComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule,
    ContactModule,
    HelpModule
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    ContactModule
  ],
  entryComponents: [
    ContactDialogComponent,
    HelpComponent
  ]
})
export class CoreModule { }
