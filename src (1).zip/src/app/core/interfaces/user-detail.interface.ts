export class UserAndOrgDetailInterface{

    name:string;
    gId:string;
    accountType:string;
    organisationList:Array<string>;


}