export interface ErrorLogInterface {
    Code: number,
    Message: string,
    MailId: string,
    Details: string
}