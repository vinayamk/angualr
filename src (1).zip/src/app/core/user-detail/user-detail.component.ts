import { Component, OnInit } from '@angular/core';

import { UserService } from '../services/user.service';
import { UserAndOrgDetailInterface } from '../interfaces/user-detail.interface';
import { AuthGuard } from '../../guards/auth.guard';
import { DataStoreService } from '../services/data-store.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
 userDetail:UserAndOrgDetailInterface;

  constructor(private userService: UserService,private authGuard:AuthGuard,private dataStoreService:DataStoreService) {
   
  }

  ngOnInit() {  
    this.userDetail  = {
        name:"",
        gId:"",
        accountType:"",
        organisationList:[]
     }
    
    this.userService.getUserDetails().subscribe((data:UserAndOrgDetailInterface) => {
        this.userDetail = data;
        this.dataStoreService.GIDBehaviorSubject.next(data.gId);
      }, error => console.log(error));
  }
}
