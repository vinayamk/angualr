import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnauthorizedComponent } from './pages/unauthorized/unauthorized.component';
import { PagenotfoundComponent } from './pages/pagenotfound/pagenotfound.component';
import { IndividualComponent } from './pages/individual/individual.component';
const routes: Routes = [
  { path: '', redirectTo: 'individual', pathMatch: 'full' },
  { path: 'unauthorized', pathMatch: 'full' ,component:UnauthorizedComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations:[UnauthorizedComponent]
})
export class AppRoutingModule { }
