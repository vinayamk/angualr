import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute,NavigationStart } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { DataStoreService } from './core/services/data-store.service';
import { UserService } from './core/services/user.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 // title = 'skill-capability-web-app';
  loader:boolean=true;
  showOrHidePage:boolean=false;
   title = 'materialApp'; 
   color = 'primary';
   mode = 'indeterminate';
   value = 50;
  constructor(private http: HttpClient,private router: Router,
    private activatedRoute: ActivatedRoute,public authGuard:AuthGuard,private dataStoreService:DataStoreService,private userService:UserService) {
           this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
              if(event.url == '/individual/jobrole' || event.url == '/individual/skills' || event.url == '/'){
                this.showOrHidePage = false;
              }else{
                  this.showOrHidePage = true;
              }
            }
          });
    }

  ngOnInit() {

  }
}
