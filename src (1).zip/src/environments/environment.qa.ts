// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    AD: {
        tenant: '66c65d8a-9158-4521-a2d8-664963db48e4',
        clientId: 'ea8e5bb7-a06a-4751-9ff1-b5306434084c',
        redirectURL: 'https://sonymyskillsqa.azurewebsites.net/'
    },
    API: {
        // baseAPIURL: 'https://sonymyskillsapiqa.azurewebsites.net/api/',
        baseAPIURL: 'https://sony-myskills-apigateway-qa.azure-api.net',
        headerNamesInInterceptor: {
            Authorization: 'Authorization',
            SubscriptionKeyName: 'Ocp-Apim-Subscription-Key'
        },
        // SubscriptionKeyValue: 'a41f934015604f10996252f7f5273437',
        SubscriptionKeyValue: '8ee923c4a0cf4f1fb0fbe93a0ef53c37',
        UserInfo_API_URLs:{
            GETRequestURLs: {
                UserInfo:"Employees/UserInfo"
            }
        },
        SurveyA_Skills_API_URLs: {
            GETRequestURLs: {
                AllEmployees: 'Employees',
                SkillCategories: 'Skills/Categories',
                RatingValues: 'Skills/Rating',
                SkillsWithRating: 'EmployeeSkills/true', // Add true to get all skills whether selected or not.
            },
            POSTRequestURLs: {
                SubmitSkills: 'EmployeeSkills',
                SubmitErrorLogs: 'Client/LogException'
            }
        },
        SurveyB_JobRole_URLs: {
            PeakTeamSize: 'JobRoles/PeakTeamSize',
            JobroleLevels: 'JobRoles/Levels',
            JobRoleGrades: 'JobRoles/Grades',
            JobRoleList: 'EmployeeJobs/true', // Add true to get total job role list for the employee.
            SaveJobRole: 'EmployeeJobs'
      },
      AuthorizationApi: "Employees/Authorize",
      IsCycleIdActiveAPi:"EmployeeSkills/isCycleActive"
    },
    matTableColumnSeperator: '⨶',
    // These names are based on the SkillAndRatingInterface. If you change that, change this.
    matTableColumnsToConsiderForSearch: [
        'firstCategory',
        'secondCategory',
        'thirdCategory',
        'fourthCategory',
        'fifthCategory',
        'skillClassification'
    ],
    DISPLAY_COLUMNS: {
        Survey_A: [
        'serialNumber',
        'skillFirstCategory',
        'skillSecondCategory',
        'skillThirdCategory',
        'skillFourthCategory',
        'skillFifthCategory',
        'rating'
        ]
    },
    NO_SKILLS_AFTER_FILTER_MESSAGE: 'No skill with this criteria',
    SKILLS_LOADING_MESSAGE: 'Loading Skills',
    MOVE_FROM_SURVEY_A_TO_B_MESSAGE: 'The data you updated on this page (Survey A) will be lost, if you leave the page. Do you want to continue?'
};
