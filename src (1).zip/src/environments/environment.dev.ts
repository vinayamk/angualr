export const environment = {
    production: false,
    AD: {
      tenant: '66c65d8a-9158-4521-a2d8-664963db48e4',
      clientId: '1f8ef06b-ee11-47c6-b042-a39a99e47c16',
      redirectURL: 'https://sonymyskillsdev.azurewebsites.net/'
    },
    API: {
      // baseAPIURL: 'https://sonymyskillsapidev.azurewebsites.net/api/',
      baseAPIURL: 'https://sonyskill.azure-api.net/dev/v1/api/',
      headerNamesInInterceptor: {
        Authorization: 'Authorization',
        SubscriptionKeyName: 'Ocp-Apim-Subscription-Key'
      },
      SubscriptionKeyValue: 'a41f934015604f10996252f7f5273437',
      UserInfo_API_URLs:{
        GETRequestURLs: {
          UserInfo:"Employees/UserInfo"
        }
      },
      SurveyA_Skills_API_URLs: {
        GETRequestURLs: {
          AllEmployees: 'Employees',
          SkillCategories: 'Skills/Categories',
          RatingValues: 'Skills/Rating',
          SkillsWithRating: 'EmployeeSkills/true', // Add true to get all skills whether selected or not.
        },
        POSTRequestURLs: {
          SubmitSkills: 'EmployeeSkills',
          SubmitErrorLogs: 'Client/LogException'
        }
      },
      SurveyB_JobRole_URLs: {
        PeakTeamSize: 'JobRoles/PeakTeamSize',
        JobroleLevels: 'JobRoles/Levels',
        JobRoleGrades: 'JobRoles/Grades',
        JobRoleList: 'EmployeeJobs/true', // Add true to get total job role list for the employee.
        SaveJobRole: 'EmployeeJobs'
      },
      AuthorizationApi:"Employees/Authorize",
      IsCycleIdActiveAPi:"EmployeeSkills/isCycleActive"   
    },
    matTableColumnSeperator: '⨶',
    // These names are based on the SkillAndRatingInterface. If you change that, change this.
    matTableColumnsToConsiderForSearch: [
      'firstCategory',
      'secondCategory',
      'thirdCategory',
      'fourthCategory',
      'fifthCategory',
      'skillClassification'
    ],
    DISPLAY_COLUMNS: {
      Survey_A: [
        'serialNumber',
        'skillFirstCategory',
        'skillSecondCategory',
        'skillThirdCategory',
        'skillFourthCategory',
        'skillFifthCategory',
        'rating'
      ]
    },
    NO_SKILLS_AFTER_FILTER_MESSAGE: 'No skill with this criteria',
    SKILLS_LOADING_MESSAGE: 'Loading Skills',
    MOVE_FROM_SURVEY_A_TO_B_MESSAGE: 'The data you updated on this page (Survey A) will be lost, if you leave the page. Do you want to continue?'
};